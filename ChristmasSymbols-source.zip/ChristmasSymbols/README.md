# ChristmasSymbols — CounterStrikeSharp

Starter source project for CounterStrikeSharp API 1.0.380.

## What this starter does
- Assigns a festive symbol to a player after they enter the server.
- Saves the assignment by SteamID in `christmas_symbols.json`, so reconnecting keeps the same symbol.
- Sets the player's CS2 clan tag (`player.Clan`) and sends a welcome message in chat.
- Chooses an unused symbol where possible; if the server has more players than symbols, symbols may repeat.

## Important limitation
This starter displays the symbol in the clan-tag area (commonly visible in the scoreboard/TAB) and in the welcome message. It does **not** rewrite every player's normal chat line to add a prefix. That requires a separate chat-formatting/hook setup and should be tested against the other chat plugins on your server.

## Build
Requires the .NET 8 SDK:
1. Open a terminal in this folder.
2. Run `dotnet restore`.
3. Run `dotnet build -c Release`.
4. Copy `bin/Release/net8.0/ChristmasSymbols.dll` and its generated dependency files into:
   `game/csgo/addons/counterstrikesharp/plugins/ChristmasSymbols/`
5. Restart the server, then check the CounterStrikeSharp log for plugin load errors.

Keep a backup of the server before installing. Test on a private/test server first. The source is provided; it is not a precompiled DLL.
