using System.Text.Json;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;

namespace ChristmasSymbols;

public class ChristmasSymbolsPlugin : BasePlugin
{
    public override string ModuleName => "ChristmasSymbols";
    public override string ModuleVersion => "1.0.0";
    public override string ModuleAuthor => "ChatGPT";
    public override string ModuleDescription => "Assigns a persistent festive clan tag to each player.";

    private readonly string[] _symbols = ["❄", "★", "✦", "♛", "✧", "雪", "✺", "❅"];
    private readonly Dictionary<string, string> _assignments = new();
    private string _dataPath = "";

    public override void Load(bool hotReload)
    {
        _dataPath = Path.Combine(ModuleDirectory, "christmas_symbols.json");
        LoadAssignments();

        RegisterListener<Listeners.OnClientPutInServer>(slot =>
        {
            // Wait briefly so the player is fully initialized and SteamID is available.
            AddTimer(2.0f, () => AssignSymbol(slot));
        });
    }

    private void AssignSymbol(int slot)
    {
        var player = Utilities.GetPlayerFromSlot(slot);
        if (player == null || !player.IsValid || player.IsBot)
            return;

        var steamId = player.AuthorizedSteamID?.ToString();
        if (string.IsNullOrWhiteSpace(steamId))
        {
            // Authorization can complete slightly later on some hosts.
            AddTimer(2.0f, () => AssignSymbol(slot));
            return;
        }

        if (!_assignments.TryGetValue(steamId, out var symbol))
        {
            var inUse = Utilities.GetPlayers()
                .Where(p => p.IsValid && !p.IsBot)
                .Select(p => p.AuthorizedSteamID?.SteamId.ToString())
                .Where(id => !string.IsNullOrWhiteSpace(id) && _assignments.ContainsKey(id!))
                .Select(id => _assignments[id!])
                .ToHashSet();

            var available = _symbols.Where(s => !inUse.Contains(s)).ToArray();
            // If there are more players than symbols, reuse one rather than failing.
            symbol = (available.Length > 0 ? available : _symbols)[Random.Shared.Next(
                available.Length > 0 ? available.Length : _symbols.Length)];

            _assignments[steamId] = symbol;
            SaveAssignments();
        }

        player.Clan = symbol;
        player.PrintToChat($" \x04[CHRISTMAS]\x01 Bine ai venit! Simbolul tău este {symbol}");
    }

    private void LoadAssignments()
    {
        try
        {
            if (File.Exists(_dataPath))
            {
                var loaded = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(_dataPath));
                if (loaded != null)
                    foreach (var pair in loaded)
                        _assignments[pair.Key] = pair.Value;
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Nu s-au putut încărca simbolurile salvate.");
        }
    }

    private void SaveAssignments()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_dataPath)!);
            File.WriteAllText(_dataPath, JsonSerializer.Serialize(_assignments,
                new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Nu s-au putut salva simbolurile.");
        }
    }
}
